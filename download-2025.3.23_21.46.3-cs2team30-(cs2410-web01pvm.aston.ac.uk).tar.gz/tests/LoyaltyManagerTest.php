use PHPUnit\Framework\TestCase;

class LoyaltyManagerTest extends TestCase
{
    public function testAddLoyaltyPoints()
    {
        $orderTotal = 100;  // Test case with an order of $100
        $expectedPoints = 10;  // Assuming 1 point per $10
        
        $loyaltyManager = new LoyaltyManager(); // Assuming you have this class
        $actualPoints = $loyaltyManager->addLoyaltyPoints($orderTotal);
        
        $this->assertEquals($expectedPoints, $actualPoints);
    }
}